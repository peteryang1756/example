This folder can be used to store any static content that you may want to link to on your status page.

You may replace the default favicons by creating icons with these names:

- favicon-16x16.png
- favicon-32x32.png
- favicon.ico

You may also replace the Netlify CMS configuration by creating an `admin` folder and placing your own `config.yml` or `index.html` file by following the project's given instructions.
