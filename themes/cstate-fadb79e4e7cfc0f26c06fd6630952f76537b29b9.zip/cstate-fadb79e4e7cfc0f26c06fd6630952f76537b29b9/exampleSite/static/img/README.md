For users of Netlify CMS with cState, `static/img` is the media folder in the config.
