---
title: Maintenance Announcement 
date: 2024-02-24 10:35:00 
informational: true
pin: true 
section: issue
---

We will shut down our network at midnight UTC on Feb 24. This does not affect the current status.
